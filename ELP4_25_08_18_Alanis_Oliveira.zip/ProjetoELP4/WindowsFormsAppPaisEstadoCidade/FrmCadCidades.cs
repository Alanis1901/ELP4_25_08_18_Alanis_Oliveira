﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsAppPaisEstadoCidade
{
    public partial class FrmCadCidades : WindowsFormsAppPaisEstadoCidade.FrmCadastros
    {
        FrmConsEstados frmConsEstados;
        Cidades aCidade;
        Controller aCtrl;

        public FrmCadCidades()
        {
            InitializeComponent();
        }

        public override void ConhecaObj(object obj, object crtl)
        {
            if (obj != null)
                aCidade = (Cidades)obj;
            if (crtl != null)
            {
                aCtrl = (Controller)crtl;
            }
        }

        protected override void Salvar()
        {
            //if (MessageDlg("Confirma (S/N)") == "S")
            aCidade.Codigo = Convert.ToInt32(txt.Text);
            aCidade.Cidade = txtCidade.Text;
            aCidade.Ddd = txtDDD.Text;
            //aCtrl.Salvar(oEstado);
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            Salvar();
        }

        public virtual void Limpartxt()
        {
            this.txt.Text = "0";
            this.txtCidade.Clear();
            this.txtDDD.Clear();
            this.txtEstado.Clear();

        }

        public virtual void Carregatxt()
        {
            this.txt.Text = Convert.ToString(aCidade);
            this.txtCidade.Text = aCidade.Cidade;
            this.txtDDD.Text = aCidade.Ddd;
            this.txtEstado.Text = aCidade.OEstado.Estado;
        }

        public virtual void Bloqueiatxt()
        {
            this.txt.Enabled = false;
            this.txtCidade.Enabled = false;
            this.txtDDD.Enabled = false;
            this.txtEstado.Enabled = false;
        }
        public virtual void Desbloqueiatxt()
        {
            this.txt.Enabled = true;
            this.txtCidade.Enabled = true;
            this.txtDDD.Enabled = true;
            this.txtEstado.Enabled = true;
        }

        public void setConsultaEstado(object obj)
        {
            frmConsEstados = (FrmConsEstados)obj;
        }

    }
}
