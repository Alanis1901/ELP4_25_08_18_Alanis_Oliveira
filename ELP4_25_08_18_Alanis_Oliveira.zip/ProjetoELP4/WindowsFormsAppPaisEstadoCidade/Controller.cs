﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsAppPaisEstadoCidade
{
    internal class Controller
    {
        public Controller()
        {

        }
        public virtual string Salvar(Object obj)
        {
            return " ";
        }
        public virtual string CarregaObj(object obj)
        {
            return "";
        }
        public virtual string Excluir(Object obj)
        {
            return " ";
        }
    }
}
