﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsAppPaisEstadoCidade
{
    public partial class FrmCadEstados : WindowsFormsAppPaisEstadoCidade.FrmCadastros
    {
        FrmConsPaises frmConsPaises;
        Estados oEstado;
        Controller aCtrl;

        public FrmCadEstados()
        {
            InitializeComponent();
        }

        public override void ConhecaObj(object obj, object crtl)
        {
            if (obj != null)
                oEstado = (Estados)obj;
            if (crtl != null)
            {
                aCtrl = (Controller)crtl;
            }
        }

        protected override void Salvar()
        {
            //if (MessageDlg("Confirma (S/N)") == "S")
            oEstado.Codigo = Convert.ToInt32(txt.Text);
            oEstado.Estado = txtEstado.Text;
            oEstado.Uf = txtUF.Text;
            //aCtrl.Salvar(oEstado);
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            Salvar();
        }

        protected override void CarregaTxt()
        {
            this.txtCodigoEstados.Text = oEstado.Codigo.ToString();
            this.txtEstado.Text = oEstado.Estado;
            this.txtUF.Text = oEstado.Uf;
            this.txtPais.Text = Convert.ToString(oEstado.OPais);
            this.txtPais.Text = oEstado.OPais.Pais;
        }

        protected override void LimpaTxt()
        {
            this.txtCodigoEstados.Text = "0";
            this.txtEstado.Clear();
            this.txtUF.Clear();
            this.txtPais.Clear();
            this.txtPais.Clear();

        }

        protected override void BloquearTxt()
        {
            this.txtEstado.Enabled = false;
            this.txtUF.Enabled = false;
            this.txtPais.Enabled = false;
            this.txtPais.Enabled = false;
        }

        protected override void DesbloquearTxt()
        {
            this.txtEstado.Enabled=false;
            this.txtUF.Enabled=false;
            this.txtPais.Enabled = true;
            this.txtPais.Enabled = true;
        }

        public void setConsultaPaises(object obj)
        {
            frmConsPaises = (FrmConsPaises)obj;
        }

        private void btnPesquisarPais_Click(object sender, EventArgs e)
        {
      
        }
    }
}
