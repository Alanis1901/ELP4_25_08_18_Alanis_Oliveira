﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsAppPaisEstadoCidade
{
    public partial class FrmConsEstados : WindowsFormsAppPaisEstadoCidade.FrmConsultas
    {
        FrmCadEstados oFrmCadEstados;
        Estados oEstado;
        Controller aCtrl;
        public FrmConsEstados()
        {
            InitializeComponent();
        }

        protected override void Pesquisar()
        {
            oFrmCadEstados.ShowDialog();
        }
        protected override void Incluir()
        {
            oFrmCadEstados.ShowDialog();
        }

        protected override void Excluir()
        {
            oFrmCadEstados.ShowDialog();
        }

        protected override void Alterar()
        {
            oFrmCadEstados.ShowDialog();
        }

        public override void setFrmCadastro(object obj)
        {
            if (obj != null)
            {
                oFrmCadEstados = (FrmCadEstados)obj;
            }
        }

        public override void ConhecaObj(object obj, object crtl)
        {
            if (obj != null)
            {
                oEstado = (Estados)obj;
            }
            if (crtl != null)
            {
                aCtrl = (Controller)crtl;
            }
        }
    }
}
