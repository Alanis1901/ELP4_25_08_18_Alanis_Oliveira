﻿namespace WindowsFormsAppPaisEstadoCidade
{
    partial class FrmCadCidades
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCidade = new System.Windows.Forms.Label();
            this.lblDDD = new System.Windows.Forms.Label();
            this.lblCodigoCidades = new System.Windows.Forms.Label();
            this.lblEstado = new System.Windows.Forms.Label();
            this.txtCidade = new System.Windows.Forms.TextBox();
            this.txtDDD = new System.Windows.Forms.TextBox();
            this.txtCodigoCidades = new System.Windows.Forms.TextBox();
            this.txtEstado = new System.Windows.Forms.TextBox();
            this.btnPesquisarCidades = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnSalvar
            // 
            this.btnSalvar.Click += new System.EventHandler(this.btnSalvar_Click);
            // 
            // lblCidade
            // 
            this.lblCidade.AutoSize = true;
            this.lblCidade.Location = new System.Drawing.Point(90, 4);
            this.lblCidade.Name = "lblCidade";
            this.lblCidade.Size = new System.Drawing.Size(44, 13);
            this.lblCidade.TabIndex = 11;
            this.lblCidade.Text = "Cidade*";
            // 
            // lblDDD
            // 
            this.lblDDD.AutoSize = true;
            this.lblDDD.Location = new System.Drawing.Point(219, 4);
            this.lblDDD.Name = "lblDDD";
            this.lblDDD.Size = new System.Drawing.Size(31, 13);
            this.lblDDD.TabIndex = 12;
            this.lblDDD.Text = "DDD";
            // 
            // lblCodigoCidades
            // 
            this.lblCodigoCidades.AutoSize = true;
            this.lblCodigoCidades.Location = new System.Drawing.Point(305, 4);
            this.lblCodigoCidades.Name = "lblCodigoCidades";
            this.lblCodigoCidades.Size = new System.Drawing.Size(40, 13);
            this.lblCodigoCidades.TabIndex = 13;
            this.lblCodigoCidades.Text = "Codigo";
            // 
            // lblEstado
            // 
            this.lblEstado.AutoSize = true;
            this.lblEstado.Location = new System.Drawing.Point(403, 4);
            this.lblEstado.Name = "lblEstado";
            this.lblEstado.Size = new System.Drawing.Size(44, 13);
            this.lblEstado.TabIndex = 14;
            this.lblEstado.Text = "Estado*";
            // 
            // txtCidade
            // 
            this.txtCidade.Location = new System.Drawing.Point(93, 19);
            this.txtCidade.Name = "txtCidade";
            this.txtCidade.Size = new System.Drawing.Size(113, 20);
            this.txtCidade.TabIndex = 15;
            // 
            // txtDDD
            // 
            this.txtDDD.Location = new System.Drawing.Point(222, 19);
            this.txtDDD.Name = "txtDDD";
            this.txtDDD.Size = new System.Drawing.Size(70, 20);
            this.txtDDD.TabIndex = 16;
            // 
            // txtCodigoCidades
            // 
            this.txtCodigoCidades.Location = new System.Drawing.Point(308, 19);
            this.txtCodigoCidades.Name = "txtCodigoCidades";
            this.txtCodigoCidades.Size = new System.Drawing.Size(78, 20);
            this.txtCodigoCidades.TabIndex = 17;
            // 
            // txtEstado
            // 
            this.txtEstado.Location = new System.Drawing.Point(406, 20);
            this.txtEstado.Name = "txtEstado";
            this.txtEstado.Size = new System.Drawing.Size(100, 20);
            this.txtEstado.TabIndex = 18;
            // 
            // btnPesquisarCidades
            // 
            this.btnPesquisarCidades.Location = new System.Drawing.Point(512, 19);
            this.btnPesquisarCidades.Name = "btnPesquisarCidades";
            this.btnPesquisarCidades.Size = new System.Drawing.Size(86, 21);
            this.btnPesquisarCidades.TabIndex = 19;
            this.btnPesquisarCidades.Text = "Pesquisar";
            this.btnPesquisarCidades.UseVisualStyleBackColor = true;
            // 
            // FrmCadCidades
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(610, 373);
            this.Controls.Add(this.btnPesquisarCidades);
            this.Controls.Add(this.txtEstado);
            this.Controls.Add(this.txtCodigoCidades);
            this.Controls.Add(this.txtDDD);
            this.Controls.Add(this.txtCidade);
            this.Controls.Add(this.lblEstado);
            this.Controls.Add(this.lblCodigoCidades);
            this.Controls.Add(this.lblDDD);
            this.Controls.Add(this.lblCidade);
            this.Name = "FrmCadCidades";
            this.Text = "Cadastro de Cidades";
            this.Controls.SetChildIndex(this.btnSair, 0);
            this.Controls.SetChildIndex(this.txt, 0);
            this.Controls.SetChildIndex(this.btnSalvar, 0);
            this.Controls.SetChildIndex(this.lblCidade, 0);
            this.Controls.SetChildIndex(this.lblDDD, 0);
            this.Controls.SetChildIndex(this.lblCodigoCidades, 0);
            this.Controls.SetChildIndex(this.lblEstado, 0);
            this.Controls.SetChildIndex(this.txtCidade, 0);
            this.Controls.SetChildIndex(this.txtDDD, 0);
            this.Controls.SetChildIndex(this.txtCodigoCidades, 0);
            this.Controls.SetChildIndex(this.txtEstado, 0);
            this.Controls.SetChildIndex(this.btnPesquisarCidades, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCidade;
        private System.Windows.Forms.Label lblDDD;
        private System.Windows.Forms.Label lblCodigoCidades;
        private System.Windows.Forms.Label lblEstado;
        private System.Windows.Forms.TextBox txtCidade;
        private System.Windows.Forms.TextBox txtDDD;
        private System.Windows.Forms.TextBox txtCodigoCidades;
        private System.Windows.Forms.TextBox txtEstado;
        protected System.Windows.Forms.Button btnPesquisarCidades;
    }
}
