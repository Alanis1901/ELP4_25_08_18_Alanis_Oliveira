﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsAppPaisEstadoCidade
{
    public partial class FrmConsCidades : WindowsFormsAppPaisEstadoCidade.FrmConsultas
    {
        FrmCadCidades oFrmCadCidades;
        Cidades aCidade;
        Controller aCtrl;
        public FrmConsCidades()
        {
            InitializeComponent();
        }

        protected override void Pesquisar()
        {
            oFrmCadCidades.ShowDialog();
        }
        protected override void Incluir()
        {
            oFrmCadCidades.ShowDialog();
        }

        protected override void Excluir()
        {
            oFrmCadCidades.ShowDialog();
        }

        protected override void Alterar()
        {
            oFrmCadCidades.ShowDialog();
        }

        public override void setFrmCadastro(object obj)
        {
            if (obj != null)
            {
                oFrmCadCidades = (FrmCadCidades)obj;
            }
        }

        public override void ConhecaObj(object obj, object crtl)
        {
            if (obj != null)
            {
                aCidade = (Cidades)obj;
            }
            if (crtl != null)
            {
                aCtrl = (Controller)crtl;
            }
        }
    }
}
