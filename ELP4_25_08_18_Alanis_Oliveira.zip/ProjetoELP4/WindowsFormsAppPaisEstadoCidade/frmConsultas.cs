﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsAppPaisEstadoCidade
{
    public partial class FrmConsultas : WindowsFormsAppPaisEstadoCidade.frm
    {
        public FrmConsultas()
        {
            InitializeComponent();
        }

    protected virtual void Pesquisar()
    {

    }
    protected virtual void Incluir()
    {

    }

    protected virtual void Excluir()
    {

    }

    protected virtual void Alterar()
    { 
      
    }

    public virtual void setFrmCadastro(object obj)
    { 
      
    }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            Pesquisar();
        }

        private void btnIncluir_Click(object sender, EventArgs e)
        {
            Incluir();
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            Alterar();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            Excluir();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Sair();
        }
    }
}
