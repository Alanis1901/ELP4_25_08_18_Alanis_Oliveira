﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsAppPaisEstadoCidade
{
    public partial class FrmCadPaises : WindowsFormsAppPaisEstadoCidade.FrmCadastros
    {
        Paises oPais;
        Controller aCtrl;
        public FrmCadPaises()
        {
            InitializeComponent();
        }

        public override void ConhecaObj(object obj, object crtl)
        {
            if (obj != null) 
                oPais = (Paises)obj;
            if (crtl != null)
            {
                aCtrl = (Controller)crtl;
            }
        }
        protected override void Salvar()
        {
            //if (MessageDlg("Confirma (S/N)") == "S")
            oPais.Codigo = Convert.ToInt32(txt.Text);
            oPais.Pais = txtPais.Text;
            oPais.Sigla = txtSigla.Text;
            oPais.Ddi = txtDDI.Text;
            oPais.Moeda = txtMoeda.Text;
            //aCtrl.Salvar(oPais);
        }
        private void btnSalvar_Click(object sender, EventArgs e)
        {
            Salvar();
        }

        protected override void CarregaTxt()
        {
            this.txt.Text = oPais.Codigo.ToString();
            this.txtPais.Text = oPais.Pais;
            this.txtSigla .Text= oPais.Sigla;
            this.txtDDI.Text = oPais.Ddi;
            this.txtMoeda.Text = oPais.Moeda;

        }

        protected override void LimpaTxt()
        {
            this.txt.Text = "0";
            this.txtPais.Clear();
            this.txtSigla.Clear();
            this.txtDDI.Clear();
            this.txtMoeda.Clear();
        }

        protected override void BloquearTxt()
        {
            this.txtPais.Enabled = false;
            this.txtSigla.Enabled = false;
            this.txtDDI.Enabled = false;
            this.txtMoeda.Enabled = false;
        }

        protected override void DesbloquearTxt()
        {
            this.txtPais.Enabled = true;
            this.txtSigla.Enabled = true;
            this.txtDDI.Enabled = true;
            this.txtMoeda.Enabled = true;
        }
    }
}
