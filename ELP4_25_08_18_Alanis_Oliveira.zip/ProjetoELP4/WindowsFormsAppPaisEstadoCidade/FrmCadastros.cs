﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsAppPaisEstadoCidade
{
    public partial class FrmCadastros : WindowsFormsAppPaisEstadoCidade.frm
    {
        public FrmCadastros()
        {
            InitializeComponent();
        }

        protected virtual void Salvar()
        {

        }
        private void btnSalvar_Click(object sender, EventArgs e)
        {
            Salvar();
        }

        protected virtual void CarregaTxt()
        {

        }

        protected virtual void LimpaTxt()
        {

        }

        protected virtual void BloquearTxt()
        {

        }

        protected virtual void DesbloquearTxt()
        {

        }
    }
}
