﻿namespace WindowsFormsAppPaisEstadoCidade
{
    partial class FrmCadEstados
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblEstado = new System.Windows.Forms.Label();
            this.lblUF = new System.Windows.Forms.Label();
            this.lblCodigoEstados = new System.Windows.Forms.Label();
            this.lblPais = new System.Windows.Forms.Label();
            this.txtEstado = new System.Windows.Forms.TextBox();
            this.txtUF = new System.Windows.Forms.TextBox();
            this.txtCodigoEstados = new System.Windows.Forms.TextBox();
            this.txtPais = new System.Windows.Forms.TextBox();
            this.btnPesquisarPais = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnSalvar
            // 
            this.btnSalvar.Click += new System.EventHandler(this.btnSalvar_Click);
            // 
            // lblEstado
            // 
            this.lblEstado.AutoSize = true;
            this.lblEstado.Location = new System.Drawing.Point(90, 4);
            this.lblEstado.Name = "lblEstado";
            this.lblEstado.Size = new System.Drawing.Size(40, 13);
            this.lblEstado.TabIndex = 11;
            this.lblEstado.Text = "Estado";
            // 
            // lblUF
            // 
            this.lblUF.AutoSize = true;
            this.lblUF.Location = new System.Drawing.Point(189, 4);
            this.lblUF.Name = "lblUF";
            this.lblUF.Size = new System.Drawing.Size(21, 13);
            this.lblUF.TabIndex = 12;
            this.lblUF.Text = "UF";
            // 
            // lblCodigoEstados
            // 
            this.lblCodigoEstados.AutoSize = true;
            this.lblCodigoEstados.Location = new System.Drawing.Point(237, 4);
            this.lblCodigoEstados.Name = "lblCodigoEstados";
            this.lblCodigoEstados.Size = new System.Drawing.Size(40, 13);
            this.lblCodigoEstados.TabIndex = 13;
            this.lblCodigoEstados.Text = "Codigo";
            // 
            // lblPais
            // 
            this.lblPais.AutoSize = true;
            this.lblPais.Location = new System.Drawing.Point(330, 4);
            this.lblPais.Name = "lblPais";
            this.lblPais.Size = new System.Drawing.Size(27, 13);
            this.lblPais.TabIndex = 14;
            this.lblPais.Text = "Pais";
            // 
            // txtEstado
            // 
            this.txtEstado.Location = new System.Drawing.Point(93, 19);
            this.txtEstado.Name = "txtEstado";
            this.txtEstado.Size = new System.Drawing.Size(85, 20);
            this.txtEstado.TabIndex = 15;
            // 
            // txtUF
            // 
            this.txtUF.Location = new System.Drawing.Point(192, 20);
            this.txtUF.Name = "txtUF";
            this.txtUF.Size = new System.Drawing.Size(38, 20);
            this.txtUF.TabIndex = 16;
            // 
            // txtCodigoEstados
            // 
            this.txtCodigoEstados.Location = new System.Drawing.Point(240, 20);
            this.txtCodigoEstados.Name = "txtCodigoEstados";
            this.txtCodigoEstados.Size = new System.Drawing.Size(73, 20);
            this.txtCodigoEstados.TabIndex = 17;
            // 
            // txtPais
            // 
            this.txtPais.Location = new System.Drawing.Point(333, 19);
            this.txtPais.Name = "txtPais";
            this.txtPais.Size = new System.Drawing.Size(70, 20);
            this.txtPais.TabIndex = 18;
            // 
            // btnPesquisarPais
            // 
            this.btnPesquisarPais.Location = new System.Drawing.Point(409, 19);
            this.btnPesquisarPais.Name = "btnPesquisarPais";
            this.btnPesquisarPais.Size = new System.Drawing.Size(95, 21);
            this.btnPesquisarPais.TabIndex = 19;
            this.btnPesquisarPais.Text = "Pesquisar";
            this.btnPesquisarPais.UseVisualStyleBackColor = true;
            this.btnPesquisarPais.Click += new System.EventHandler(this.btnPesquisarPais_Click);
            // 
            // FrmCadEstados
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(610, 373);
            this.Controls.Add(this.btnPesquisarPais);
            this.Controls.Add(this.txtPais);
            this.Controls.Add(this.txtCodigoEstados);
            this.Controls.Add(this.txtUF);
            this.Controls.Add(this.txtEstado);
            this.Controls.Add(this.lblPais);
            this.Controls.Add(this.lblCodigoEstados);
            this.Controls.Add(this.lblUF);
            this.Controls.Add(this.lblEstado);
            this.Name = "FrmCadEstados";
            this.Text = "Cadastro de Estados";
            this.Controls.SetChildIndex(this.btnSair, 0);
            this.Controls.SetChildIndex(this.txt, 0);
            this.Controls.SetChildIndex(this.btnSalvar, 0);
            this.Controls.SetChildIndex(this.lblEstado, 0);
            this.Controls.SetChildIndex(this.lblUF, 0);
            this.Controls.SetChildIndex(this.lblCodigoEstados, 0);
            this.Controls.SetChildIndex(this.lblPais, 0);
            this.Controls.SetChildIndex(this.txtEstado, 0);
            this.Controls.SetChildIndex(this.txtUF, 0);
            this.Controls.SetChildIndex(this.txtCodigoEstados, 0);
            this.Controls.SetChildIndex(this.txtPais, 0);
            this.Controls.SetChildIndex(this.btnPesquisarPais, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblEstado;
        private System.Windows.Forms.Label lblUF;
        private System.Windows.Forms.Label lblCodigoEstados;
        private System.Windows.Forms.Label lblPais;
        private System.Windows.Forms.TextBox txtEstado;
        private System.Windows.Forms.TextBox txtUF;
        private System.Windows.Forms.TextBox txtCodigoEstados;
        private System.Windows.Forms.TextBox txtPais;
        protected System.Windows.Forms.Button btnPesquisarPais;
    }
}
